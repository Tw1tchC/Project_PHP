<!DOCTYPE html>
<html lang="pl">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Contact us</title>
    <link rel="stylesheet" type="text/css" href="contact.css">
</head>
  <body class="tło">
    <h1>Skontaktuj się z nami</h1>
    <?php
// connect to the database 
$mysqli = new mysqli('localhost', 'root', '', 'php_project_by_adrian_kulik');

// check connection
if ($mysqli->connect_error) {
  die('Connection failed: ' . $mysqli->connect_error);
}

// get form data and sanitize inputs
$name = filter_input(INPUT_POST, 'name', );
$email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
$subject = filter_input(INPUT_POST, 'subject', );
$message = filter_input(INPUT_POST, 'message', );

// prepare and execute query
$stmt = $mysqli->prepare("INSERT INTO messages (name, email, subject, message) VALUES (?, ?, ?, ?)");
$stmt->bind_param("ssss", $name, $email, $subject, $message);

if ($stmt->execute()) {
  echo "Message sent successfully.";
} else {
  echo "Error: " . $stmt->error;
}

$stmt->close();
$mysqli->close();
?>
    <form>
      <form action="save_message.php" method="post">
        <label for="name">Name:</label>
        <input type="text" id="name" name="name" required><br>
      
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required><br>
      
        <label for="subject">Subject:</label>
        <input type="text" id="subject" name="subject" required><br>
      
        <label for="message">Message:</label>
        <textarea id="message" name="message" required></textarea><br>
      
        <button type="submit">Send</button>
      </form>

  </body>
</html>